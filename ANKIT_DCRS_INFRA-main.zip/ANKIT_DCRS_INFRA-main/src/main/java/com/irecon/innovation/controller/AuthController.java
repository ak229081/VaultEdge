/*
 * package com.irecon.innovation.controller;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity; import
 * org.springframework.security.authentication.AuthenticationManager; import
 * org.springframework.security.authentication.
 * UsernamePasswordAuthenticationToken; import
 * org.springframework.security.core.userdetails.UserDetails; import
 * org.springframework.security.core.userdetails.UserDetailsService; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.web.bind.annotation.*;
 * 
 * import com.irecon.innovation.entity.User; import
 * com.irecon.innovation.model.AuthRequest; import
 * com.irecon.innovation.model.AuthResponse; import
 * com.irecon.innovation.services.Impl.UserService; import
 * com.irecon.innovation.utility.JwtUtil;
 * 
 * @Controller public class AuthController {
 * 
 * @Autowired private AuthenticationManager authenticationManager;
 * 
 * @Autowired private JwtUtil jwtUtil;
 * 
 * @Autowired private UserDetailsService userDetailsService;
 * 
 * @Autowired private UserService userService;
 * 
 * @GetMapping(value = { "I-RECON", "/" }) public String loginUser() { return
 * "LoginUser"; }
 * 
 * @PostMapping("/auth/login") public ResponseEntity<?>
 * loginUser(@RequestParam("userid") String userid,
 * 
 * @RequestParam("password") String password) {
 * 
 * 
 * 
 * 
 * System.out.println("post " + userid + " " + password); User user =
 * userService.loginUser(userid, password); if (user != null) { String token =
 * jwtUtil.generateToken(userid); // or user.getUsername() based on your
 * UserDetails System.out.println("token " + token); return new
 * ResponseEntity<>("JWT Token: " + token, HttpStatus.OK);
 * 
 * } else { return new ResponseEntity<>("Invalid Credentials",
 * HttpStatus.UNAUTHORIZED); } }
 * 
 * }
 */